Directory for auto-generated documents

e.g. SchemaHTML, HistoryHTML
